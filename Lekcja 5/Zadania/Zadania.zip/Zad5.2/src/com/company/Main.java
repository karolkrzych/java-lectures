package com.company;

public class Main {

    public static void main(String[] args) {
        //Declare integer two-dimension table and initialize all elements by sum squares of indexes and print all elements
    }
}
