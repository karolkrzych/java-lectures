package com.company;

public class Main {

    public static void main(String[] args) {
        // Initialize one-dimension table with your name and surname and print it char by char in one line and use all loop types
    }
}
