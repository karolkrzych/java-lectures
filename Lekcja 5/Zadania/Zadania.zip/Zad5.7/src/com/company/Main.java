package com.company;

public class Main {

    public static void main(String[] args) {
	// Write all prime numbers between 2 and 100 (look on sieve of Eratosthenes)
    }
}
