package com.company;

public class Main {

    public static void main(String[] args) {
	// Declare and initialize table with random chars and count how many char duplicates exist in this table and write information about it
    }
}
