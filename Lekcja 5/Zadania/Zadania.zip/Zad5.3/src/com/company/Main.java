package com.company;

public class Main {

    public static void main(String[] args) {
	/* Print to console rectangular triangle of hight 10 builded from stars
	Example :

	*
	**
	***
	****
	*****
	******
	*******
	********
	*********
	**********

	 */
    }
}
