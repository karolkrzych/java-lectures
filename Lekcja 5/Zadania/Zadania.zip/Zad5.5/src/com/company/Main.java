package com.company;

public class Main {

    public static void main(String[] args) {
        // Initialize one-dimension table with random word and check this word is palindrome
    }
}
