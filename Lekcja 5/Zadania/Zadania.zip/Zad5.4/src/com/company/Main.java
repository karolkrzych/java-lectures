package com.company;

public class Main {

    public static void main(String[] args) {
        // Print to console chess board shape
    }
}
